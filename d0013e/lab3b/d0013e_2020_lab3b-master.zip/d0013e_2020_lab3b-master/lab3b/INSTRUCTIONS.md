# Instructions

Copy your `lab3.s` file here (from your `lab3a` folder).
