#include <stdio.h>

char plain[132];

int coded[] = {
0x4d6ec864,
0x662b2a78,
0x90e1d561,
0xa32c6327,
0x0454404a,
0x92e05487,
0x5375d43a,
0xf9e567ac,
0x43371577,
0x32b736b8,
0x49a5ec76,
0x6ebff5d7,
0xfb738300,
0x74294164,
0xf23ef15f,
0x24c58cea,
0x61c1fdb0,
0x48198857,
0xea7354bf,
0x893208c5,
0xce3ecad4,
0x0a9b9803,
0x5f995c00,
0x252bc0d0,
0xcffe1782,
0x15eadb1e,
0xdc6c31ce,
0x9af2e8d2,
0x49e4d76a,
0x3acdb702,
0x163a6879,
0xc2f4c81d,
0xf26eda94,
0x8d077e47,
0x18aa46e1,
0x2585749a,
0xb139ed3b,
0xce0a088e,
0x1d592615,
0x7d93da2a,
0x2607d487,
0x61741405,
0xa48e5cc3,
0x47afd4f0,
0x778b680d,
0x45845cfe,
0x224439d8,
0xbe731c7f,
0x75a44066,
0x38eebb4d,
0xaa976178,
0x05f347b7,
0x1f23c815,
0xcbc45c38,
0xcd511bc0,
0x9f848d13,
0x9eb4a4d4,
0x528e6b88,
0xcea7dda1,
0x8a98fef8,
0xea78be0e,
0xb5d81ca8,
0x663db1f1,
0xd336026c,
0xcadc5625,
0x64eb599e,
0xf2752d49,
0xc1ee12e5,
0x0627778b,
0xcc618e9d,
0x9eaf66fb,
0x6e38c014,
0x6e68c9db,
0xd09c3990,
0x964bbe63,
0x8416a064,
0xf556359c,
0xc9df16d1,
0x04363bc0,
0x92e175ca,
0xfda65aa4,
0x7306ed47,
0x8673ecab,
0xfc3b2c5e,
0xe02f0a67,
0x546bdf68,
0 
};

int abc[] = {0xf7411388, 0x425a18e1, 0x18e3d7e2, 0};

unsigned int seed = 0x27c3ec84;

int codgen(unsigned int *seed_addr) {
    int n, x, y, i;
	int c = 0;
	
	// Count the number of 1's in word seed
	for (i = 31; i >= 0; i--) {
		n = *seed_addr >> i;
		if (n & 1) {
			c++;
		}
	}

    x = *seed_addr << 2;                // Shift seed left-logical by 2 bits
    y = *seed_addr / 16;                // Divide seed by the constant 16
    *seed_addr = x ^ y ^ c;             // x XOR y XOR c;
    return (*seed_addr ^ 0x6dbce25f);   // Return (seed XOR 0x6dbce25f)
}

int decode(int *wordarr, char *bytearr, int *seed_addr) {
    unsigned int m, r, x, y;
	x = ~codgen(seed_addr); // One's complement

    // If contents of word at wordarr = 0, then byte pointed to by bytearr = 0 and r = x
	if (*wordarr == 0) {
	    *bytearr = 0;
		r = x;
	}
    else {
        y = decode(wordarr + 1, bytearr + 1, seed_addr);
		m = (x - y) + *wordarr;         // m = ( x - y ) + [contents of word at "wordarr"];
		*bytearr = (m >> 19) & 0xff;    // Byte at bytarr = m <26:19>
		r = (~codgen(seed_addr)) + 1;   // Two's complement
		r = x + y + m + r + 5;
    }
	return r;
}

int main() {
    decode(coded, plain, &seed);
    printf("%s", plain);
    printf("\n");
}
